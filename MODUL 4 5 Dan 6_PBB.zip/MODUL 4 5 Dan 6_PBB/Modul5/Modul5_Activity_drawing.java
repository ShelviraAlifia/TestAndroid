package com.example.sutrisno.helloworld.Modul5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.sutrisno.helloworld.R;

public class Modul5_Activity_drawing extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modul5_drawing);
    }
}
